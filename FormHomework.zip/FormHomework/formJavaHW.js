function processForm() {
    var newText = document.getElementById("name").value;
    document.getElementById("oldText").innerHTML = newText;
    var newWidth = document.getElementById("width").value;
    var newHeight = document.getElementById("height").value;
    document.getElementById("box").style.width = newWidth + "px"; 
    document.getElementById("box").style.height = newHeight + "px";
    if (document.getElementById("border").checked) {
        var newBorder = document.getElementById("border").value;
        document.getElementById("box").style.border = newBorder;
}
    if (document.getElementById("border0").checked) {
        var newBorder0 = document.getElementById("border0").value;
        document.getElementById("box").style.border = newBorder0;         
}  
    if (document.getElementById("border1").checked) {
        var newBorder1 = document.getElementById("border1").value;
        document.getElementById("box").style.border = newBorder1;         
}
    var newColor = document.getElementById("color").value;
    document.getElementById("box").style.backgroundColor = newColor;
{
  if (isNaN(newWidth)) 
  {
    alert("Must input numbers for Width");
    return false;
  }
  if (isNaN(newHeight)) 
  {
    alert("Must input numbers for Height");
    return false;
  }
}
}
